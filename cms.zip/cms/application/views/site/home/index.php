<div id="right">
                    <div class="panel">
  <div class="panel-heading bg-blue text-uppercase">
  Sản Phẩm Mới  </div>
  <div class="panel-body">                                                                                                                                
                                                        
                            
                            <!--<script type="text/javascript">
  function addProduct(id)
  { 
    var path = baseURL + '/widgets/products-categories/helpers/add.php';
    var formData = {
      id: id,
      isAjax: 1
    };
    
    var request = $.ajax({
      type: 'POST',
      url: path,
      data: formData,
      async: false,
      success: function(response){
        $('#shoppingcart').html(response);
      }
    });
  }
</script>-->
    <script type="text/javascript">
  $(document).ready(function () {
    $('#slick-30').slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplaySpeed: 0,
        dots: true,
        infinite: true,
        speed: 1000,
        slide: 'div',
        cssEase: 'linear',
        autoplay: true
      });
    });
  </script>
    <div class="ul-product row" id="slick-30">
      <?php foreach($product_newest as $row) : ?>
          <div class="col-3 text-center" style="padding-bottom:10px;margin-bottom:20px; border-right:1px dotted #ddd">            
              <p>
                  <a href="<?php echo base_url('product/view/'.$row->id)?>" title="<?=$row->name?>">
                    <img style="max-height:120px; margin:auto" alt="" src="<?php echo base_url('/upload/product/'.$row->image_link)?>" alt="<?=$row->name?>" title="<?=$row->name?>">
                    <span class="tooltip">
                      <img style="width:250px" alt="" src="<?php echo base_url('/upload/product/'.$row->image_link)?>" alt="<?=$row->name?>" title="<?=$row->name?>">
                      <span style="font-size:110%; color:#F00; font-weight:bold">

                      <?php if($row->discount > 0) :?>
                      <?php $price_new = $row->price - $row->discount; ?>
                      <?php echo number_format($price_new) ?>đ <span class="price_old"><?php echo number_format($row->price) ?> đ</span>
                    <?php else : ?>
                      <?php echo number_format($row->price) ?>đ
                    <?php endif ?></span></span>
                  </a>
              </p>
              <a style="display:block;height:30px;color:#000" <?php echo base_url('product/view/'.$row->id)?>" title="<?=$row->name?>"><?=$row->name?> </a>
              <p style="margin-top:10px" style="color:#FF3300">
              <span style="font-size:110%; color:#F00; font-weight:bold">
                  <?php if($row->discount > 0) :?>
                      <?php $price_new = $row->price - $row->discount; ?>
                      <?php echo number_format($price_new) ?>đ <span class="price_old"><?php echo number_format($row->price) ?> đ</span>
                    <?php else : ?>
                      <?php echo number_format($row->price) ?>đ
                    <?php endif ?>    
              </span>
              </p>

              <!--<a class="btn btn-primary" onclick="addProduct('1')" data-toggle="modal" data-target="#myModal"><span class="glyphicon glyphicon-shopping-cart"></span> Mua hàng</a>-->

              <a class="btn btn-primary" href="<?php echo base_url('product/view/'.$row->id)?>"><span class="glyphicon glyphicon-shopping-cart"></span> Xem chi tiết</a>

        </div>
      <?php endforeach ?>
    </div> 

                       
  </div>
</div>
<div class="panel">
  <div class="panel-heading bg-teal text-uppercase">
  Sản Phẩm được mua nhiều nhất  </div>
  <div class="panel-body"><!--<script type="text/javascript">
  function addProduct(id)
  { 
    var path = baseURL + '/widgets/products-categories/helpers/add.php';
    var formData = {
      id: id,
      isAjax: 1
    };
    
    var request = $.ajax({
      type: 'POST',
      url: path,
      data: formData,
      async: false,
      success: function(response){
        $('#shoppingcart').html(response);
      }
    });
  }
</script>-->
    <script type="text/javascript">
  $(document).ready(function () {
    $('#slick-31').slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplaySpeed: 1442,
        dots: true,
        infinite: true,
        speed: 500,
        slide: 'div',
        cssEase: 'linear',
        autoplay: true
      });
    });
  </script>
    <div class="ul-product row" id="slick-31">
      <?php foreach($product_buyed as $row) : ?>
      <div class="col-3 text-center" style="padding-bottom:10px;margin-bottom:20px; border-right:1px dotted #ddd">            
        <p style="height:120px">
            <a href="<?php echo base_url('product/view/'.$row->id)?>" title="<?=$row->name?>">
              <img style="max-height:120px; margin:auto" alt="" src="<?php echo base_url('/upload/product/'.$row->image_link)?>" alt="<?=$row->name?>" title="<?=$row->name?>">
                <span class="tooltip"><img style="width:250px" alt="" src="<?php echo base_url('/upload/product/'.$row->image_link)?>" alt="<?=$row->name?>" title="<?=$row->name?>">
                  <span style="font-size:110%; color:#F00; font-weight:bold">
                    <?php if($row->discount > 0) :?>
                      <?php $price_new = $row->price - $row->discount; ?>
                      <?php echo number_format($price_new) ?>đ <span class="price_old"><?php echo number_format($row->price) ?> đ</span>
                    <?php else : ?>
                      <?php echo number_format($row->price) ?>đ
                    <?php endif ?>
                </span>
              </span>
            </a>
        </p>
        <a style="display:block;height:30px;color:#000" href="<?php echo base_url('product/view/'.$row->id)?>" title="<?=$row->name?>"><?=$row->name?></a>
        <p style="margin-top:10px" style="color:#FF3300">
          <span style="font-size:110%; color:#F00; font-weight:bold">
              <?php if($row->discount > 0) :?>
                <?php $price_new = $row->price - $row->discount; ?>
                <?php echo number_format($price_new) ?>đ <span class="price_old"><?php echo number_format($row->price) ?> đ</span>
              <?php else : ?>
                <?php echo number_format($row->price) ?>đ
              <?php endif ?>
          </span>
        </p>

        <!--<a class="btn btn-primary" onclick="addProduct('107')" data-toggle="modal" data-target="#myModal"><span class="glyphicon glyphicon-shopping-cart"></span> Mua hàng</a>-->

        <a class="btn btn-primary" href="<?php echo base_url('product/view/'.$row->id)?>" title="<?=$row->name?>"><span class="glyphicon glyphicon-shopping-cart"></span> Xem chi tiết</a>

    </div>
    <?php endforeach?>
        
    </div>                    
  </div>
</div><div class="panel">
  <div class="panel-heading bg-purple text-uppercase">
  Mực in  </div>
  <div class="panel-body"><!--<script type="text/javascript">
  function addProduct(id)
  { 
    var path = baseURL + '/widgets/products-categories/helpers/add.php';
    var formData = {
      id: id,
      isAjax: 1
    };
    
    var request = $.ajax({
      type: 'POST',
      url: path,
      data: formData,
      async: false,
      success: function(response){
        $('#shoppingcart').html(response);
      }
    });
  }
</script>-->
    <script type="text/javascript">
  $(document).ready(function () {
    $('#slick-32').slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplaySpeed: 4721,
        dots: true,
        infinite: true,
        speed: 500,
        slide: 'div',
        cssEase: 'linear',
        autoplay: true
      });
    });
  </script>
    <div class="ul-product row" id="slick-32">
        <?php foreach($product_newest as $row) : ?>
          <div class="col-3 text-center" style="padding-bottom:10px;margin-bottom:20px; border-right:1px dotted #ddd">            
              <p style="height:120px">
                  <a href="<?php echo base_url('product/view/'.$row->id)?>" title="<?=$row->name?>">
                    <img style="max-height:120px; margin:auto" alt="" src="<?php echo base_url('/upload/product/'.$row->image_link)?>" alt="<?=$row->name?>" title="<?=$row->name?>">
                    <span class="tooltip">
                      <img style="width:250px" alt="" src="<?php echo base_url('/upload/product/'.$row->image_link)?>" alt="<?=$row->name?>" title="<?=$row->name?>">
                      <span style="font-size:110%; color:#F00; font-weight:bold">

                      <?php if($row->discount > 0) :?>
                      <?php $price_new = $row->price - $row->discount; ?>
                      <?php echo number_format($price_new) ?>đ <span class="price_old"><?php echo number_format($row->price) ?> đ</span>
                    <?php else : ?>
                      <?php echo number_format($row->price) ?>đ
                    <?php endif ?></span></span>
                  </a>
              </p>
              <a style="display:block;height:30px;color:#000" <?php echo base_url('product/view/'.$row->id)?>" title="<?=$row->name?>"><?=$row->name?> </a>
              <p style="margin-top:10px" style="color:#FF3300">
              <span style="font-size:110%; color:#F00; font-weight:bold">
                  <?php if($row->discount > 0) :?>
                      <?php $price_new = $row->price - $row->discount; ?>
                      <?php echo number_format($price_new) ?>đ <span class="price_old"><?php echo number_format($row->price) ?> đ</span>
                    <?php else : ?>
                      <?php echo number_format($row->price) ?>đ
                    <?php endif ?>    
              </span>
              </p>

              <!--<a class="btn btn-primary" onclick="addProduct('1')" data-toggle="modal" data-target="#myModal"><span class="glyphicon glyphicon-shopping-cart"></span> Mua hàng</a>-->

              <a class="btn btn-primary" href="<?php echo base_url('product/view/'.$row->id)?>"><span class="glyphicon glyphicon-shopping-cart"></span> Xem chi tiết</a>

        </div>
      <?php endforeach ?>

    </div>                    

  </div>
</div><div class="panel">
  <div class="panel-heading bg-purple text-uppercase">
  Bài viết  </div>
  <div class="panel-body">
<ul class="media-list" id="carousel33">
      <?php foreach($news_list as $row) : ?>
      <li class="media">
          <a class="pull-left" href="<?php echo site_url('news/view/'.$row->id) ?>" title="<?=$row->title?>">
            <img width="64" height="64" class="media-object" src="<?php echo base_url('upload/news/'.$row->image_link) ?>" alt="<?=$row->title?>" title="<?=$row->title?>">
          </a>
          <div class="media-body">
            <a href="<?php echo site_url('news/view/'.$row->id) ?>" title="<?=$row->title?>"><?=$row->title?></a>
          </div>
        </li>
      <?php endforeach ?>
    
  </ul>
<p class="text-center">
<a class="btn btn-primary" href="<?php echo site_url('tin-tuc') ?>">Xem thêm</a>
</p>
                            
                            </div>
</div>                </div>
                        <div class="clearfix"></div>