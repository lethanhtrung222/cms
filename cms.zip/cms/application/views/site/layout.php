<!DOCTYPE html>
<html>
	<head>
		<?php $this->load->view('site/head.php');?>
	</head>
	<body>
		    <?php $this->load->view('site/header.php');?>
		    
		    
		      <?php $this->load->view('site/left.php', $this->data);?>
		      
		      	 
		      		<?php if(isset($message)) : ?>
		      			<p style="color:red;"><?php echo $message; ?></p>
		      		<?php endif?>
		      		<?php $this->load->view($temp, $this->data);?>
			
				<img src="<?php echo public_url()?>/site/images/bank.png"> 
		  	
		  	
		   		<?php $this->load->view('site/footer.php');?>
		   	
	   	
	</body>
</html>