<div id="container">
  <div class="panel panel-default">
    <div class="panel-body">
        <div class="page-header" style="margin-top:0">
            <h1 style="margin-top:0"><a href="<?php echo base_url('tin-tuc')?>">Tin Tức</a></h1>
        </div>
        <ul class="media-list">
            <?php foreach($news_list as $row) : ?>
              <li class="media">
                  <a class="pull-left" href="<?php echo base_url('news/view/'.$row->id)?>" title="<?=$row->title?>">
                      <img width="140" class="media-object img-thumbnail" src="<?php echo base_url('/upload/news/'.$row->image_link)?>" alt="<?=$row->title?>" title="<?=$row->title?>">
                  </a>
                  <div class="media-body">
                      <h4 style="margin-top:0"><a href="<?php echo base_url('news/view/'.$row->id)?>" title="<?=$row->title?>"><?=$row->title?>                     </a></h4>
                      <p>
                          <?php 
                              if(strlen($row->intro) < 20){
                                  echo $row->intro;
                              }else{
                                echo mb_substr($row->intro,0,100,'utf8').'...';
                              }
                          ?>
                      </p>
                  </div>
                  <div class="clearfix"></div>
                </li>
            <?php endforeach ?>      
          </ul>
        <div class="text-center">
            <a class="btn btn-primary" href="<?php echo base_url('tin-tuc')?>">Xem thêm <span class="glyphicon glyphicon-arrow-right"></span></a>
        </div>
    </div>
  </div>
</div>