<div id="container">                             
<div class="panel panel-default">
    <div class="panel-body">
        <form id="frmContact" method="post" role="form">    
          <div>  
                <div class="text-left"><strong>Tổng Tiền Thanh Toán: <font color="#FF0000" size="+1"><?php echo number_format($total_amount) ?> đ</font></strong></div>
                <script type="text/javascript">
                  $(document).ready(function(e) {
                         $('#frmContact').submit(function(e){
                  if($('#fullname').val().trim() == ''
                    || $('#email').val().trim() == ''
                    || $('#phone').val().trim() == ''
                    || $('#address').val().trim() == ''
                  )
                  {
                    alert('Vui lòng điền đầy đủ thông tin!');
                    return false;
                  }
                });
                    });
                </script>
                
                <div class="page-header">
                    <h1>Thông tin thanh toán</h1>
                </div>
                <div>
                <div class="margin-bottom">
                    <label>Họ tên</label>
                    <input id="fullname" type="text" name="name" class="form-control" placeholder="Nhập họ tên">
                </div>
                <div class="margin-bottom">
                    <label>Email</label>
                    <input id="email" type="email" name="email" class="form-control" placeholder="Nhập email">
                </div>
                <div class="margin-bottom">
                    <label>Số điện thoại</label>
                    <input id="phone" type="text" name="phone" class="form-control" placeholder="Nhập điện thoại">
                </div>
                <div class="margin-bottom">
                    <label>Địa chỉ giao hàng</label>
                    <input id="address" type="text" name="message" class="form-control" placeholder="Số nhà, đường, tổ, ấp, phường xã">
                </div>
                <div class="margin-bottom">
                    <select name="payment">
                          <option value="">---- Chọn Hình Thức Thanh Toán ----</option>
                          <option value="offline">Thanh Toán Khi Nhận Hàng</option>
                          <option value="atcomputer">Giao dịch tại công ty</option>
                          <option value="atpostoffice">Giao dịch wa bưu điện</option> 
                    </select>
                </div>
                <button type="submit" class="btn btn-primary btn-lg"> Thanh toán</button>
                </div>
            </div>
        </form>
      </div>
    </div>
</div>