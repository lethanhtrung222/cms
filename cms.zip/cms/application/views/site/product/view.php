<div id="container"> 
    <div class="panel panel-default">
    <div class="panel-body">
        <form method="post">
            <div class="page-header" style="margin-top:0">
                <h1><?php echo $product->name ?></h1>
            </div>
            <div class="row">
                <div class="col-5">
                    <img width="100%" alt="" src="<?php echo base_url('upload/product/'.$product->image_link)?>">
                </div>
                <div class="col-7">
                    <input name="id" type="hidden" value="1">
                    <div class="margin-bottom">
                        <strong>Tình trạng:</strong>
                        <i>Còn hàng</i>
                    </div>
                    <div class="margin-bottom">
                    <strong>Giá bán: 
                        <span style="color:rgb(255, 0, 0); font-size:18px">
                            <?php if($product->discount > 0) :?>
                              <?php $price_new = $product->price - $product->discount; ?>
                              <span class='product_price'><?php echo number_format($price_new) ?>đ</span>
                              
                              <span class="price_old"><?php echo number_format($product->price) ?> đ</span>
                            <?php else : ?>
                                <span class='product_price'><?php echo number_format($product->price) ?> đ</span> 
                              
                            <?php endif ?>                   
                        </span>
                    </strong> 
                    </div>
                    
                    <div class="margin-bottom">
                        <strong>Bảo hành:</strong>
                        <span>
                            <?php if($product->warranty != ""):?>
                               
                                  <b><?=$product->warranty ?></b> 
                                
                            <?php endif;?>
                        </span> 
                    </div>
                   
                    <a class='btn btn-primary btn-lg' style='float:left;padding:8px 15px;font-size:16px' href="<?php echo base_url('cart/add/'.$product->id) ?>" title='Mua ngay'>Thêm vào giỏ hàng</a>                    
                </div>
            </div>
            <fieldset>
                <legend class="color-indigo">Thông tin chi tiết</legend>
                <div class="article"><table id="product-attribute-specs-table" style="line-height:18.6000003814697px; width:0px">
    <tbody>
        <tr>
            <th>Tên sản phẩm</th>
            <td><?php echo $product->name ?></td>
        </tr>
        <tr>
            <th>Nội Dung</th>
            <td><?php echo $product->content ?></td>
        </tr>
        <tr>
            <th>Giá Bán</th>
            <td><?php echo number_format($product->price) ?> đ</td>
        </tr>
        <tr>
            <th>Bảo Hành</th>
            <td><?php echo $product->warranty?></td>
        </tr>
        <tr>
            <th>Quà Tặng</th>
            <td><?php echo $product->gifts?></td>
        </tr>
        
    </tbody>
</table>


</div>
                
            
            
            <!-- ADDTHIS BUTTON END -->
            </fieldset>

            <div class="panel">
  <div class="panel-heading bg-teal text-uppercase">
  Sản Phẩm Cùng Loại  </div>
  <div class="panel-body"><!--<script type="text/javascript">
  function addProduct(id)
  { 
    var path = baseURL + '/widgets/products-categories/helpers/add.php';
    var formData = {
      id: id,
      isAjax: 1
    };
    
    var request = $.ajax({
      type: 'POST',
      url: path,
      data: formData,
      async: false,
      success: function(response){
        $('#shoppingcart').html(response);
      }
    });
  }
</script>-->
    <script type="text/javascript">
  $(document).ready(function () {
    $('#slick-31').slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplaySpeed: 1442,
        dots: true,
        infinite: true,
        speed: 500,
        slide: 'div',
        cssEase: 'linear',
        autoplay: true
      });
    });
  </script>
    <div class="ul-product row" id="slick-31">
      <?php foreach($product_buyed as $row) : ?>
      <div class="col-3 text-center" style="padding-bottom:10px;margin-bottom:20px; border-right:1px dotted #ddd">            
        <p style="height:120px">
            <a href="<?php echo base_url('product/view/'.$row->id)?>" title="<?=$row->name?>">
              <img style="max-height:120px; margin:auto" alt="" src="<?php echo base_url('/upload/product/'.$row->image_link)?>" alt="<?=$row->name?>" title="<?=$row->name?>">
                <span class="tooltip"><img style="width:250px" alt="" src="<?php echo base_url('/upload/product/'.$row->image_link)?>" alt="<?=$row->name?>" title="<?=$row->name?>">
                  <span style="font-size:110%; color:#F00; font-weight:bold">
                    <?php if($row->discount > 0) :?>
                      <?php $price_new = $row->price - $row->discount; ?>
                      <?php echo number_format($price_new) ?>đ <span class="price_old"><?php echo number_format($row->price) ?> đ</span>
                    <?php else : ?>
                      <?php echo number_format($row->price) ?>đ
                    <?php endif ?>
                </span>
              </span>
            </a>
        </p>
        <a style="display:block;height:30px;color:#000" href="<?php echo base_url('product/view/'.$row->id)?>" title="<?=$row->name?>"><?=$row->name?></a>
        <p style="margin-top:10px" style="color:#FF3300">
          <span style="font-size:110%; color:#F00; font-weight:bold">
              <?php if($row->discount > 0) :?>
                <?php $price_new = $row->price - $row->discount; ?>
                <?php echo number_format($price_new) ?>đ <span class="price_old"><?php echo number_format($row->price) ?> đ</span>
              <?php else : ?>
                <?php echo number_format($row->price) ?>đ
              <?php endif ?>
          </span>
        </p>

        <!--<a class="btn btn-primary" onclick="addProduct('107')" data-toggle="modal" data-target="#myModal"><span class="glyphicon glyphicon-shopping-cart"></span> Mua hàng</a>-->

        <a class="btn btn-primary" href="<?php echo base_url('product/view/'.$row->id)?>" title="<?=$row->name?>"><span class="glyphicon glyphicon-shopping-cart"></span> Xem chi tiết</a>

    </div>
    <?php endforeach?>
        
    </div>                    
  </div>
</div>



            
        </form>
    </div>
</div>
</div>
