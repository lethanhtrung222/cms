<div id="container">            
    <div class="panel panel-default">
        <div class="panel-body">
            <div class="page-header" style="margin-top:0">
              <h1 style="margin-top:0"><?=$catalog->name?>(có <?php echo $total_rows ?> sản phẩm )</h1>
            </div>
            <div class="ul-product row">
                <?php foreach($list as $row) : ?>
                    <div class="col-3 text-center" style="padding-bottom:10px;margin-bottom:20px; border-right:1px dotted #ddd">            
                        <p style="height:120px">
                            <a href="<?php echo base_url('product/view/'.$row->id)?>" title="<?=$row->name?>">
                                <img style="max-height:120px; margin:auto" src="<?php echo base_url('/upload/product/'.$row->image_link)?>" alt="<?=$row->name?>" title="<?=$row->name?>">
                                <span class="tooltip"><img style="width:250px"  src="<?php echo base_url('/upload/product/'.$row->image_link)?>" alt="<?=$row->name?>" title="<?=$row->name?>">
                                    <span style="font-size:110%; color:#F00; font-weight:bold">
                                        <?php if($row->discount > 0) :?>
                                          <?php $price_new = $row->price - $row->discount; ?>
                                          <?php echo number_format($price_new) ?>đ <span class="price_old"><?php echo number_format($row->price) ?> đ</span>
                                        <?php else : ?>
                                          <?php echo number_format($row->price) ?>đ
                                        <?php endif ?>
                                    </span>
                                </span>
                            </a>
                        </p>
                        <a style="display:block;height:30px;color:#000" href="<?php echo base_url('product/view/'.$row->id)?>" title="<?=$row->name?>"><?=$row->name?>  </a>
                        <p style="margin-top:10px">
                            <span style="font-size:110%; color:#F00; font-weight:bold">
                                <?php if($row->discount > 0) :?>
                                  <?php $price_new = $row->price - $row->discount; ?>
                                  <?php echo number_format($price_new) ?>đ <span class="price_old"><?php echo number_format($row->price) ?> đ</span>
                                <?php else : ?>
                                  <?php echo number_format($row->price) ?>đ
                                <?php endif ?> 
                            </span>
                        </p>

                        <!--<a class="btn btn-primary" onclick="addProduct('1')" data-toggle="modal" data-target="#myModal"><span class="glyphicon glyphicon-shopping-cart"></span> Mua hàng</a>-->

                        <a class="btn btn-primary" href="<?php echo base_url('product/view/'.$row->id)?>"><span class="glyphicon glyphicon-shopping-cart"></span> Xem chi tiết</a>

                    </div>
                <?php endforeach?>  
            </div>
      </div>
    </div>
</div>