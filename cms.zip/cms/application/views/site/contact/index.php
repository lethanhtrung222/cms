<?php 
		echo "<h1>".$contact_list->title."</h1>";
		echo "<br />";
		echo $contact_list->content;
	
?>