
    <div id="all">
        <header id="header">
            <div class="logo">
                <a href="<?php  echo base_url()?>">
                    <img src="<?php echo public_url('site/images/logo.jpg'); ?>">
                </a>
            </div>
            
            <div class="hotline">
                <div>
                  <div>HOTLINE: 098.845.2075 &ndash; 0909.401.579</div>
                  <br />
                  <br />
                   <!--  load gio hàng -->
                  <div id="cart_expand" class="cart"> 
                        <a href="<?php echo base_url('cart'); ?>" class="cart_link">
                           Giỏ hàng <span id="in_cart"><?php echo $total_items ?></span> sản phẩm
                        </a> 
                        <img alt="cart bnc" src="<?php echo public_url()?>/site/images/cart.png"> 
                  </div>  
                </div>
            </div>
            <!--  load gio hàng -->
        </header>
        <div id="wrapper">
          <div id="top">
                <div>
                    <div class="marquee" style="padding: 7px; text-align: right; background-color: rgb(63, 81, 181);">
                        <p>
                            <span style="color:#FFFFFF">Địa chỉ: 373/1 L&yacute; Thường Kiệt,phường 9,Q.T&acirc;n B&igrave;nh, Tp. Hồ Ch&iacute; Minh</span>
                        </p>
                    </div>
                </div>
            <div>
  <style type="text/css">
    .navbar-primary{
    background-color: #303F9F;
    }
    .navbar-primary a:hover{
        background-color: #283593;
    }
    .navbar-primary .active{
        background-color: #283593;  
    }
</style>
<script type="text/javascript">
$(function() {
    $( "#text-search" ).autocomplete({
        source: "<?php echo site_url('product/search/1') ?>",
    });
});
</script>
<nav class="navbar navbar-primary text-uppercase">
    <ul style="widget:90%; float:left">
        <li>
            <a href="<?php echo base_url() ?>" title="Về trang chủ">Trang Chủ</a>
        </li>
                <li class="txt-uppercase">
            <a href="<?php echo site_url('gioi-thieu') ?>" target="_parent">Giới thiệu</a>
        </li>
            <li class="txt-uppercase">
            <a href="<?php echo site_url('dich-vu') ?>" target="_parent">Dịch vụ</a>
        </li>
            <li class="txt-uppercase">
            <a href="<?php echo site_url('lien-he') ?>" target="_parent">Liên hệ</a>
        </li>
            <li class="txt-uppercase">
            <a href="<?php echo site_url('tin-tuc') ?>" target="_parent">Tin tức</a>
        </li>
            <li class="txt-uppercase">
            <a href="<?php echo site_url('driver') ?>" target="_parent"> driver</a>
        </li>
            <li class="txt-uppercase">
            <a href="<?php echo site_url('bang-gia') ?>" target="_parent">BẢNG GIÁ</a>
        </li>
            <li class="txt-uppercase">
            <a href="<?php echo site_url('san-pham') ?>" target="_parent">Sản phẩm</a>
        </li>
            <li class="txt-uppercase">
            <a href="<?php echo site_url('hoi-dap') ?>" target="_parent">Hỏi đáp</a>
        </li>
        </ul>
            

        <form  style="float:right; margin:7px 10px 0 0" method="get" action="<?php echo base_url('product/search') ?>">
                <input  style="width:240px; padding:5px; border:0; border-radius:0"   type="text" id="text-search" name="key-search" value="<?php echo isset($key) ? $key : "" ?>" placeholder="Tìm kiếm sản phẩm..." class="ui-autocomplete-input" autocomplete="off" role="textbox" aria-autocomplete="list" aria-haspopup="true">
                <input style=" padding:5px; border:0; border-radius:0"  type="submit" id="but" name="but" value="Tìm Kiếm">
        </form>
           
    <div class="clearfix"></div>

</nav>
                            </div>

                        </div>

<?php 
      $this->load->view('site/slide.php', $this->data);
?>
            <div id="sidebar"><div class="panel">
  
</div>

