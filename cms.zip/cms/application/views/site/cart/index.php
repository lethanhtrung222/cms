<div id="container">
    <div class="page-header" style="margin-top:0">
        <h1>Thông tin giỏ hàng (có <?php echo $total_items ?> sản phẩm )</h1>
    </div> 
    <?php if($total_items > 0) : ?>
        <form method="post"  action="<?php echo base_url('cart/update')?>">
            <table class="table table-bordered table-striped table-hover">
                <thead>
                    <tr>
                        <th class="text-center">STT</th>
                        <th class="text-center">Sản phẩm</th>
                        <th class="text-center">Đơn giá (VNĐ)</th>
                        <th class="text-center">Số lượng</th>
                        <th class="text-center">Thành tiền</th>
                        <th>Xóa</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $total_amount = 0; ?>
                    <?php foreach ($carts as $row):?>
                        <?php $total_amount = $total_amount + $row['subtotal']?>
                    <tr>
                        <td class="text-center">1</td>
                        <td><?=$row['name']?></td>
                        <td class="text-right"><?=number_format($row['price'])?></td>
                        <td class="text-center">
                            <input class="form-control" name="qty_<?php echo $row['id'] ?>" style="width:70px" min="1" type="number" value="<?=$row['qty']?>"></td>
                        </td>
                        <td class="text-right"><?=number_format($row['subtotal'])?></td>
                        <td class="text-center"><a href="<?php echo base_url('cart/del/'.$row['id']) ?>" style="color:#F00">Xóa</a></td>
                    </tr>
                    <?php endforeach?>
                </tbody>
            </table>
            <div class="clearfix"></div>
            <div class="text-right">
                <strong>Tổng tiền: <span style="color: rgb(255, 0, 0); font-size:16px"><?php echo number_format($total_amount)?>đ </span></strong>
            </div>
            <button type="submit" class="btn btn-primary" style="padding:10px 15px">Cập nhật giỏ hàng</button>
            
            <a href="<?php echo base_url() ?>" class="btn btn-primary"><span class="glyphicon glyphicon-chevron-left"></span> Tiếp tục mua hàng</a>
            <div class="clearfix"></div>
            <a style="float:right;" class="btn btn-primary" href="<?php echo site_url('order/checkout') ?>">Thanh toán</a>
        </form>
    <?php else : ?>
        <h2> Không có sản phẩm nào trong giỏ hàng </h2>
    <?php endif?>
</div>