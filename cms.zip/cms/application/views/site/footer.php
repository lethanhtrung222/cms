<section id="bottom"><div class="panel">
  <div class="panel-body"><script>
  $(document).ready(function () {
    $('#slick-8').slick({
      autoplaySpeed: 2724,
      dots: true,
      infinite: true,
      speed: 500,
      fade: true,
      slide: 'div',
      cssEase: 'linear',
      autoplay: true
    });
  });
</script>
<div id="slick-8" class="row">
    <div class="col-3" style="padding:0"><img src="http://tinhocdinhvang.com/media/images/banners/dremel-3d-banner.jpg"></div><div class="col-3" style="padding:0"><img src="http://tinhocdinhvang.com/media/images/banners/Printer-Banner.jpg"></div><div class="col-3" style="padding:0"><img src="http://tinhocdinhvang.com/media/images/banners/smart-banner-50s.jpg"></div><div class="col-3" style="padding:0"><img src="http://tinhocdinhvang.com/media/images/banners/Dell_2.jpg"></div><div class="col-3" style="padding:0"><img src="http://tinhocdinhvang.com/media/images/banners/smart-banner-50d.jpg"></div></div>
<div class="margin-bottom"></div></div>
</div><div class="panel">
  <div class="panel-body"><p valign="bottom"><img alt="" src="http://tinhocdinhvang.com/media/images/logo/1(1).png" style="height:50px; width:136px" /><img alt="" src="http://tinhocdinhvang.com/media/images/logo/1.png" style="height:50px; width:70px" /><img alt="" src="http://tinhocdinhvang.com/media/images/logo/2.jpg" style="height:50px; width:82px" /><img alt="" src="http://tinhocdinhvang.com/media/images/logo/2.png" style="height:50px; width:70px" /><img alt="" src="http://tinhocdinhvang.com/media/images/logo/3.png" style="height:50px; width:70px" /><img alt="" src="http://tinhocdinhvang.com/media/images/logo/New-Ricoh-Logo-Red-on-White-Background.jpg" style="height:30px; width:170px" /><img alt="" src="http://tinhocdinhvang.com/media/images/logo/olivetti_logo_2468.gif" style="height:30px; width:116px" /><img alt="" src="http://tinhocdinhvang.com/media/images/logo/samsung-logo.jpeg" style="height:30px; width:68px" /><img alt="" src="http://tinhocdinhvang.com/media/images/logo/sony-logo.jpg" style="height:30px; width:198px" /><img alt="" src="http://tinhocdinhvang.com/media/images/logo/Xerox-logo3.jpg" style="height:40px; width:112px" /></p>
</div>
</div></section>
        </div>
        <footer id="footer"><div class="panel">
  <div class="panel-heading bg-red text-uppercase">
  Copyright </div>
  <div class="panel-body"><p style="text-align:center"><strong>C&ocirc;ng ty TNHH TMDV Tin Học Đỉnh V&agrave;ng</strong><br />
<strong>Địa chỉ</strong>: 373/1 L&yacute; Thường Kiệt, Q. T&acirc;n B&igrave;nh, Tp. Hồ Ch&iacute; Minh</p>

<p style="text-align:center"><strong>Điện thoại</strong>: (08) 3868.8131/(08)2223.5557</p>

<p style="text-align:center"><strong>Fax</strong>: (08) 3868.8132&nbsp;<strong>Email</strong>:&nbsp;<a href="mailto:info@mucindinhvang.com">info@mucindinhvang.com</a></p>
</div>
</div></footer>
    </div>
