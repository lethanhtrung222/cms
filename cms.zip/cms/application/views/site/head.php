
<title>crack web</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Tin Học Đỉnh Vàng-0909401579, nạp mực in,sửa máy in, máy tính, máy photo, cho thuê máy photocopy,  sua may tinh, sua may tinh tan noi."/>
<meta name="keywords" content="Nạp mực in, nap muc in, nạp mực tận nơi, nạp mực tân bình, đỉnh vàng, nạp mực tân bình giá rẻ, máy in giá rẻ tân bình, nạp mực in giá rẻ hcm, bơm mực, sua maay tinh"/>
<meta name="language" content="vi"/>
<meta name="author" content="coconut"/>
<meta name="rights" content="rights"/>
<meta name="copyright" content="copyright 2014"/>
<meta name="generator" content="generator"/>
<meta name="robots" content="index, archive, follow, noodp"/>
<meta name="googlebot" content="index, archive, follow, noodp"/>
<meta name="msnbot" content="all,index,follow"/>
<link rel="icon" href="http://tinhocdinhvang.com/templates/shop/images/favicon.ico" type="image/x-icon">
<!-- Facebook -->
<meta property="og:title" content="Công ty TNHH TMDV Tin Học Đỉnh Vàng">
<meta property="og:type" content="article">
<meta property="og:description" content="Tin Học Đỉnh Vàng-0909401579, nạp mực in,sửa máy in, máy tính, máy photo, cho thuê máy photocopy,  sua may tinh, sua may tinh tan noi.">
<meta property="og:image" content="">
<meta property="og:url" content="http://tinhocdinhvang.com/">
<!-- Google+ -->
<meta itemprop="name" content="Công ty TNHH TMDV Tin Học Đỉnh Vàng">
<meta itemprop="description" content="Tin Học Đỉnh Vàng-0909401579, nạp mực in,sửa máy in, máy tính, máy photo, cho thuê máy photocopy,  sua may tinh, sua may tinh tan noi.">
<meta itemprop="image" content="">
<meta itemprop="url" content="<?php echo base_url()?>">
<!-- Jquery 1.11.1 -->
<script type="text/javascript" src="http://tinhocdinhvang.com/assets/js/jquery-1.11.1.min.js"></script>
<!-- Core CSS -->
<link type="text/css" href="<?php echo public_url()?>site/css/style.css" rel="stylesheet">


<link rel="stylesheet" type="text/css" href="<?php echo public_url()?>site/css/temp/style.css" />
<!-- Font Awesome 4.2.0 -->
<link rel="stylesheet" type="text/css" href="http://tinhocdinhvang.com/assets/font-awesome/4.2.0/css/font-awesome.min.css" />

<!-- Slick -->
<script type="text/javascript" src="http://tinhocdinhvang.com/assets/slick/slick.min.js"></script>
<link rel="stylesheet" href="http://tinhocdinhvang.com/assets/slick/slick.css" type="text/css">
<link rel="stylesheet" media="screen" type="text/css" href="http://tinhocdinhvang.com/templates/shop/css/tooltips.css" />
<script type="text/javascript" src="<?php echo public_url()?>/js/jquery/autocomplete/jquery-ui-1.8.16.custom.min.js"></script>

<!-- <script type="text/javascript" src="<?php echo public_url()?>/js/jquery/jquery.min.js"></script>
<script type="text/javascript" src="<?php echo public_url()?>/js/jquery/jquery-ui.min.js"></script> -->

<!-- Google Analytics -->
