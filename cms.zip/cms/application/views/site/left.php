<div class="panel">
	<div class="panel-heading bg-red text-uppercase">
	Danh mục sản phẩm	</div>
	<div class="panel-body">
		<ul class="nav-vertical">

			<?php foreach($catalog_list as $row) : ?>
          		<?php 
          			$name = convert_vi_to_en($row->name); 
          			$name = strtolower($name);
          		?>
			<li class="sub">
				<a href="<?php echo base_url($name.'-c'.$row->id) ?>" title="<?=$row->name?>">
					<?=$row->name?>
				</a>
				<?php  if(!empty($row->subs)) : ?>
				<ul>
					 <?php foreach($row->subs as $sub) : ?>	
	             	 	    <?php 
			          			$name = convert_vi_to_en($sub->name); 
			          			$name = strtolower($name);
			          		?>
					<li >
						<a href="<?php echo base_url($name.'-c'.$sub->id) ?>" title="<?= $sub->name ?>"">
							<?= $sub->name ?>		
						</a>
					</li>
					<?php endforeach?>								
				</ul>
				<?php endif?>
			</li>	
			<?php endforeach ?>

		</ul>
	</div>
</div>
<div class="panel">
	<div class="panel-heading bg-teal text-uppercase">
	Hình ảnh công ty	</div>
	<div class="panel-body"><script>
	$(document).ready(function () {
		$('#slick-34').slick({
			autoplaySpeed: 3769,
			dots: true,
			infinite: true,
			speed: 500,
			fade: true,
			slide: 'div',
			cssEase: 'linear',
			autoplay: true
		});
	});
</script>
<div id="slick-34" class="row">
    <div class="col-3" style="padding:0"><img src="http://tinhocdinhvang.com/media/images/san-pham/qc-muc-in-2.jpg"></div>
    <div class="col-3" style="padding:0"><img src="http://tinhocdinhvang.com/media/images/san-pham/qc-muc-in-1.jpg"></div>
    <div class="col-3" style="padding:0"><img src="http://tinhocdinhvang.com/media/images/san-pham/qc-muc-in-3.jpg"></div>
    <div class="col-3" style="padding:0"><img src="http://tinhocdinhvang.com/media/images/san-pham/qc-muc-in-4.jpg"></div>
</div>
<div class="margin-bottom"></div></div>
</div></div>