<?php 
	Class Catalog_model extends MY_Model{
		var $table = 'catalog';
	}