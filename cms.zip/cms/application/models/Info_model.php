<?php 
	Class Info_model extends MY_Model{
		var $table = 'info';
	}