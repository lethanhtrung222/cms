/* Brazilian initialisation for the jQuery UI multiselect plugin. */
/* Written by Yusuf Özer (realsby@gmail.com). */

(function ( $ ) {

$.extend($.ech.multiselectfilter.prototype.options, {
  label: "Filtre:",
  placeholder: "Bir kelime yazın"
});

})( jQuery );
